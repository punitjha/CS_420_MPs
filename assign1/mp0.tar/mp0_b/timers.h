#include <sys/time.h>

double get_clock();
