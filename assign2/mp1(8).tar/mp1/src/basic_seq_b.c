extern double A[N][M];
extern double B[M][N];
extern double C[N][N];

/**
 * The better dense matrix multiply.
 * Implement an improvement of the first version without tiling.
 */
void basic_better_MM()
{ 
    int i, j, k;
    for (i = 0; i < N; ++i) {
        for (j = 0; j < N; ++j) {
            for (k = 0; k < M; ++k) {
                // --
                // Implement your code here.
                // --
            }
        }
    }
}
