extern double A[N][M];
extern double B[M][N];
extern double C[N][N];

/**
 * Implement cache-aware matrix multiply.
 */
void cache_aware_MM()
{
    // -- 
    // Implement your code here
    // -- 
}
